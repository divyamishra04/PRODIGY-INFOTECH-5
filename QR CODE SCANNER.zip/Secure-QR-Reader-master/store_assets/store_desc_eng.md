# Title
QR Reader Secure

# Short Desc
Privacy Focused and Secure QR Reader

# Long desc

Protect your privacy with a trustworthy QR reader!

Say goodbye to sneaky spyware that invades your phone and steals your data. This QR reader is designed with your security in mind, so you can scan with confidence. Unlike other apps, it doesn't require strange and unnecessary permissions or bombard you with ads and trackers. Your privacy is respected, and what you scan stays on your phone.

Rest assured, the only permission requested is for your camera, ensuring a seamless scanning experience. Additionally, the app is open source, allowing you to inspect the code for added transparency and peace of mind.

Stay secure and scan worry-free with this QR reader!

Discover the open source code here: https://github.com/prof18/Secure-QR-Reader

