
# Title
QR Reader Sicuro

# Short Desc
Lettore di QR sicuro ed attento alla privacy

# Long desc

Non installare virus sul tuo telefono!

Questo lettore di codici QR non richiede permessi strani ed inutili solo per rubare i tuoi dati. Non ci sono pubblicità, i dati non vengono tracciati e quello che scansioni rimane nel tuo cellulare. L'unico permesso richiesto è quello per usare la fotocamera

Scansiona, ma rimani al sicuro!

L'app è open source, puoi guardare il codice: https://github.com/prof18/Secure-QR-Reader










